/*FIT-MARKET 
Mercado y/o tienda virtual enfocada en la venta minorista de productos relacionados con la salud y nutrición.
Incluyendo proteínas, vitaminas, anábolicos, entre otros. Con servicio de 'Delivery' para los clientes del GAM, en: 
San José, Costa Rica.


//PASOS-A-SEGUIR-->Simulador://

1. INTRO. 
Ingresar Nombre > Incorporar número de teléfono > Aparece mensaje de 'Bienvenido/a' + Número ingresado + Mensaje: 
'Ya puedes iniciar tu pedido..'.

2. AGREGAR-A-CARRITO. 

  > Se le pregunta al usuario: '¿Cuántos productos quieres ingresar en tu carrito?'
  > Entonces, luego debe ingresar: Nombre del producto > En moneda $(dólar), el precio del producto > Cantidad del producto.
  > Seguido, se obtiene el 'Total de la compra' + un mensaje: 
  'Nos comunicaremos contigo en menos de 24hrs, el siguiente número.. "XXX"'(para acordar entrega de pedido)'.

3. FILTRADO. 

  > Se le indica al usuario que tiene opción de búsqueda de un Producto: 
  'Si deseas, ingresa un término de búsqueda y/o producto'
  > Si se ingresa adecuadamente alguno de los siguientes productos (es decir, una sección del nombre y/o el nombre completo):

    - Proteína
    - Vitaminas
    - Aminoácido
    - Fibra

      * Aparece un mensaje: 'Se encontraron "XX" productos que coinciden con "XXX"' ("Producto-encontrado") > Luego, se presenta
      el 'Nombre + Precio' del Producto.
      * Después, se le pregunta al usuario: '¿Quieres guardar "XXX" en Favoritos? (Si/No)' ("Producto-encontrado").

          > Respuesta 'Si': se le indica que el producto '"XXX" ha sido guardado en Favoritos'.
          > Respuesta 'No': Se cierra la ventana inmediatamente.


  > Si ingresa el nombre del producto incorrectamente y/o no conforme a la lista de Productos predeterminada, aparece una 
  ventana que dice: 'No se encontraron productos que coincidan con "XXX" ("Producto-ingresado").
*/



///INGRESO///

let nombre = prompt("¡Hola! Ingresa tu nombre:");
let telefono = prompt("Por favor ingresa tu número de teléfono:");

alert("👋 ¡Bienvenido/a a Fit Market"+ " " + nombre + "!" + " " + "Gracias por proporcionarnos tu número de teléfono. Ya puedes iniciar tu pedido.");


///AGREGAR-A-CARRITO///

//Se le pide al usuario que ingrese los detalles de cada producto y los agregamos al carrito.
const numProductos = parseInt(prompt("🛒 ¿Cuántos productos quieres ingresar en tu carrito?"));

//Función de orden superior que recibe una 'función callback' y un 'número de productos'
function sumarProductosEnCarrito(numProductos, callback) {
  let carrito = [];
  // Pedimos al usuario que ingrese los productos y los almacenamos en un 'array'.
  for (let i = 0; i < numProductos; i++) {
    const nombre = prompt("Ingresa el nombre del producto " + (i+1));
    const precio = parseFloat(prompt("Ingresa en moneda $(dólar) el precio del producto " + (i+1)));
    const cantidad = parseInt(prompt("Ingresa la cantidad del producto " + (i+1)));
    carrito.push({ nombre, precio, cantidad });
  }

  //Se usa la 'función callback' para obtener el 'valor' de cada producto.
  const valores = carrito.map(callback);

  //Usamos el método 'reduce' para obtener la suma total de los valores.
  const total = valores.reduce((acumulado, valor) => acumulado + valor, 0);

  //Se retorna la suma total.
  return total;
}

//Operación - 'Función callback' que recibe un 'objeto producto' y retorna el 'valor del producto'.
function obtenerValorProducto(producto) {
  return producto.precio * producto.cantidad;
}

//Se utiliza la 'función de orden superior' para obtener 'la suma total de los productos'.
const total = sumarProductosEnCarrito(numProductos, obtenerValorProducto);

//Se muestra al usuario 'el total de la compra'.
alert("El total de tu compra es: $" + total + "  " + "\n📳 Nos comunicaremos contigo en menos de 24 horas, en el siguiente número de teléfono: " + telefono);


///FILTRADO///

/*Se define una 'función constructora' para crear objetos de tipo Producto. Esta función tomará dos parámetros: 
el 'nombre y el precio' del producto. */
function Producto(nombre, precio) {
  this.nombre = nombre;
  this.precio = precio;
}

//Se define un 'array' de productos saludables.
const productosSaludables = [
  {nombre: 'Proteína', precio: 43.09},
  {nombre: 'Vitaminas', precio: 23.23},
  {nombre: 'Aminoácidos', precio: 27.78},
  {nombre: 'Fibra', precio: 9.83},
]

//Se establece la función para buscar un producto, con 'filter'.
function buscarProducto(productos, terminoBusqueda) {
  return productos.filter(function(producto) {
    return producto.nombre.toLowerCase().includes(terminoBusqueda.toLowerCase());
  });
}

//Se define la función para preguntar si el usuario quiere guardar un producto en 'Favoritos'.
function preguntarGuardarEnFavoritos(producto) {
  const respuesta = prompt(`¿Quieres guardar "${producto.nombre}" en Favoritos? (Si/No)`);
  if (respuesta.toLowerCase() === "si") {
    //Aquí se guardar el producto en 'Favoritos'.
    alert(`✅ "${producto.nombre}" ha sido guardado en Favoritos.`);
  }
}

//Se le pide al usuario que ingrese un 'término de búsqueda'.
const terminoBusqueda = prompt("🔍 Si deseas, ingresa un término de búsqueda y/o producto:");

//Acá se buscan los productos que coinciden con el 'término de búsqueda'.
const productosEncontrados = buscarProducto(productosSaludables, terminoBusqueda);

if (productosEncontrados.length === 0) {
  alert(`⛔ No se encontraron productos que coincidan con "${terminoBusqueda}".`);
} else {
  alert(`✅ Se encontraron ${productosEncontrados.length} productos que coinciden con "${terminoBusqueda}".`);
  //Se muestran los 'productos encontrados' al usuario.
  for (let i = 0; i < productosEncontrados.length; i++) {
    alert(`Nombre: ${productosEncontrados[i].nombre} | Precio: $${productosEncontrados[i].precio}`);
    //Se pregunta si el usuario quiere 'guardar el producto en favoritos'.
    preguntarGuardarEnFavoritos(productosEncontrados[i]);
  }
}